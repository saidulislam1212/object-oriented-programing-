package VariableClass_10;

import java.util.Scanner;

class EmployeeData {
    int empid;
    String name;
    double salary;

    public void AcceptData(int id, String empName, double empSalary) {
        this.empid = id;
        this.name = empName;
        this.salary = empSalary;
    }

    public void DisplayData() {
        System.out.println("EmployeeData ID: " + empid);
        System.out.println("Name: " + name);
        System.out.println("Salary: " + salary);
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        EmployeeData[] employees = new EmployeeData[5];
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < employees.length; i++) {
            employees[i] = new EmployeeData();

            System.out.print("Enter Employee ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter EmployeeD Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Employee Salary: ");
            double salary = sc.nextDouble();

            employees[i].AcceptData(id, name, salary);
            System.out.println();
        }

        System.out.println("Employee Details here:");
        for (int i = 0; i < employees.length; i++) {
            employees[i].DisplayData();
        }


    }
}

