package VariableClass_4;

import java.util.Scanner;

class RevNum {
    int num;
    public void setNumber(int number) {
        this.num = number;
    }

    public int RevNumber() {
        int rev = 0;
        int temp = num;

        while (temp != 0) {
            int remainder = temp % 10;
            rev = rev * 10 + remainder;
            temp = temp / 10;
        }
        return rev;
    }

    public void display() {
        System.out.println("Original number: " + num);
        System.out.println("Reversed number: " + RevNumber());
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        RevNum nr = new RevNum();

        System.out.print("Enter a 3-digit number: ");
        int number = scanner.nextInt();

        if (number >= 100 && number <= 999) {
            nr.setNumber(number);
            nr.display();
        } else {
            System.out.println("Please enter a valid 3-digit number.");
        }
    }
}
